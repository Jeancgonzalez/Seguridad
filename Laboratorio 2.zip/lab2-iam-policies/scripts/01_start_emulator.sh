#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# 01 - Levanta el emulador de AWS (moto) que reemplaza a LocalStack.
#      Expone la API de AWS en http://localhost:4566 (mismo endpoint del doc).
# ---------------------------------------------------------------------------
source "$(dirname "${BASH_SOURCE[0]}")/lib.sh"

PORT=4566
LOG_FILE="${PROJECT_DIR}/.run/moto.log"
PID_FILE="${PROJECT_DIR}/.run/moto.pid"
mkdir -p "${PROJECT_DIR}/.run"

if curl -s -m 2 -o /dev/null "http://localhost:${PORT}/"; then
  ok "El emulador ya está en ejecución en http://localhost:${PORT}"
  exit 0
fi

log "Iniciando emulador moto (sustituto de LocalStack) en el puerto ${PORT}"
setsid env MOTO_IAM_LOAD_MANAGED_POLICIES=true \
  "${VENV_BIN}/moto_server" -H 127.0.0.1 -p "${PORT}" \
  > "${LOG_FILE}" 2>&1 < /dev/null &
echo $! > "${PID_FILE}"

for _ in $(seq 1 20); do
  if curl -s -m 2 -o /dev/null "http://localhost:${PORT}/"; then
    ok "Emulador listo (PID $(cat "${PID_FILE}"))"
    exit 0
  fi
  sleep 1
done

warn "No se pudo confirmar el arranque. Revisa ${LOG_FILE}"
exit 1
