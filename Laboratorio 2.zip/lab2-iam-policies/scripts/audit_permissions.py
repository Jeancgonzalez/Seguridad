#!/usr/bin/env python3
"""Mini evaluador de políticas IAM para demostrar el principio de mínimo privilegio.

Lee las políticas asociadas a un usuario en el emulador (moto/LocalStack) y
evalúa si una lista de acciones de alto riesgo quedan PERMITIDAS o DENEGADAS.
No sustituye a IAM Access Analyzer ni a `simulate-principal-policy`, pero sirve
como evidencia reproducible "antes vs después" en el laboratorio.
"""
import argparse
import fnmatch
import json
import sys

import boto3


RISKY_ACTIONS = [
    ("iam:CreateUser", "*", "Crear usuarios (persistencia)"),
    ("iam:CreateAccessKey", "*", "Crear claves de acceso"),
    ("iam:AttachUserPolicy", "*", "Auto-asignarse privilegios"),
    ("s3:GetObject", "arn:aws:s3:::empresa-datos-sensibles/contraseñas.txt",
     "Leer secreto en bucket AUTORIZADO"),
    ("s3:GetObject", "arn:aws:s3:::otro-bucket-privado/clave.txt",
     "Leer bucket NO autorizado"),
    ("s3:DeleteBucket", "arn:aws:s3:::empresa-datos-sensibles", "Borrar el bucket"),
    ("ec2:TerminateInstances", "*", "Apagar servidores"),
]


def load_policy_documents(iam, user):
    """Devuelve la lista de documentos JSON de las políticas del usuario."""
    documents = []

    attached = iam.list_attached_user_policies(UserName=user)["AttachedPolicies"]
    for policy in attached:
        arn = policy["PolicyArn"]
        version = iam.get_policy(PolicyArn=arn)["Policy"]["DefaultVersionId"]
        doc = iam.get_policy_version(PolicyArn=arn, VersionId=version)
        documents.append(doc["PolicyVersion"]["Document"])

    inline_names = iam.list_user_policies(UserName=user)["PolicyNames"]
    for name in inline_names:
        doc = iam.get_user_policy(UserName=user, PolicyName=name)
        documents.append(doc["PolicyDocument"])

    return attached, documents


def action_matches(pattern, action):
    if pattern == "*":
        return True
    return fnmatch.fnmatchcase(action.lower(), pattern.lower())


def resource_matches(pattern, resource):
    if pattern == "*":
        return True
    return fnmatch.fnmatchcase(resource, pattern)


def is_allowed(documents, action, resource):
    for doc in documents:
        statements = doc.get("Statement", [])
        if isinstance(statements, dict):
            statements = [statements]
        for st in statements:
            if st.get("Effect") != "Allow":
                continue
            actions = st.get("Action", [])
            if isinstance(actions, str):
                actions = [actions]
            resources = st.get("Resource", [])
            if isinstance(resources, str):
                resources = [resources]
            action_ok = any(action_matches(a, action) for a in actions)
            resource_ok = any(resource_matches(r, resource) for r in resources)
            if action_ok and resource_ok:
                return True
    return False


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--endpoint-url", default="http://localhost:4566")
    parser.add_argument("--user", default="usuario-desarrollo")
    parser.add_argument("--region", default="us-east-1")
    args = parser.parse_args()

    iam = boto3.client(
        "iam",
        endpoint_url=args.endpoint_url,
        region_name=args.region,
        aws_access_key_id="test",
        aws_secret_access_key="test",
    )

    attached, documents = load_policy_documents(iam, args.user)

    print(f"Usuario evaluado : {args.user}")
    print("Políticas activas : " + ", ".join(p["PolicyName"] for p in attached)
          if attached else "Políticas activas : (ninguna)")
    print("-" * 78)
    print(f"{'ACCIÓN SOLICITADA':<28}{'RESULTADO':<12}{'DESCRIPCIÓN'}")
    print("-" * 78)

    denied = 0
    for action, resource, desc in RISKY_ACTIONS:
        allowed = is_allowed(documents, action, resource)
        result = "PERMITIDO" if allowed else "DENEGADO"
        if not allowed:
            denied += 1
        print(f"{action:<28}{result:<12}{desc}")

    print("-" * 78)
    print(f"Acciones de alto riesgo DENEGADAS: {denied}/{len(RISKY_ACTIONS)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
