#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# Lab 2 - IAM: Políticas inseguras y Mínimo Privilegio
# Jean Carlos Gonzalez Aragon
# Configuración común para todos los scripts del laboratorio.
# ---------------------------------------------------------------------------

set -euo pipefail

LAB_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PROJECT_DIR="$(cd "${LAB_DIR}/.." && pwd)"

VENV_BIN="${PROJECT_DIR}/.venv/bin"
AWS="${VENV_BIN}/aws"
PYTHON="${VENV_BIN}/python"

ENDPOINT_URL="http://localhost:4566"
export AWS_ACCESS_KEY_ID="test"
export AWS_SECRET_ACCESS_KEY="test"
export AWS_DEFAULT_REGION="us-east-1"
export AWS_EC2_METADATA_DISABLED="true"

USER_NAME="usuario-desarrollo"
ADMIN_POLICY_ARN="arn:aws:iam::aws:policy/AdministratorAccess"
CUSTOM_POLICY_NAME="MinimoPrivilegio-S3-Lectura"
CUSTOM_POLICY_ARN="arn:aws:iam::123456789012:policy/${CUSTOM_POLICY_NAME}"
BUCKET="empresa-datos-sensibles"

EVIDENCE_DIR="${LAB_DIR}/evidence"
mkdir -p "${EVIDENCE_DIR}"

aws() {
  "${AWS}" --endpoint-url "${ENDPOINT_URL}" "$@"
}

log() {
  printf '\n\033[1;36m==> %s\033[0m\n' "$*"
}

ok() {
  printf '\033[1;32m[OK]\033[0m %s\n' "$*"
}

warn() {
  printf '\033[1;33m[!]\033[0m %s\n' "$*"
}
