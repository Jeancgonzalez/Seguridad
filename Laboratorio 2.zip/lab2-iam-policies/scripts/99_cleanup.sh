#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# 99 - Limpieza: elimina usuario, política, buckets y detiene el emulador.
# ---------------------------------------------------------------------------
source "$(dirname "${BASH_SOURCE[0]}")/lib.sh"

log "1. Desvincular y eliminar políticas del usuario"
aws iam detach-user-policy --user-name "${USER_NAME}" \
  --policy-arn "${ADMIN_POLICY_ARN}" 2>/dev/null || true
aws iam detach-user-policy --user-name "${USER_NAME}" \
  --policy-arn "${CUSTOM_POLICY_ARN}" 2>/dev/null || true

log "2. Eliminar usuario ${USER_NAME}"
aws iam delete-user --user-name "${USER_NAME}" 2>/dev/null || true

log "3. Eliminar política personalizada"
aws iam delete-policy --policy-arn "${CUSTOM_POLICY_ARN}" 2>/dev/null || true

log "4. Detener el emulador moto"
if [[ -f "${PROJECT_DIR}/.run/moto.pid" ]]; then
  kill "$(cat "${PROJECT_DIR}/.run/moto.pid")" 2>/dev/null || true
  rm -f "${PROJECT_DIR}/.run/moto.pid"
fi

ok "Limpieza completada."
