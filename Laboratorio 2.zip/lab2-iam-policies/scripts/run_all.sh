#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# run_all.sh - Ejecuta el Laboratorio 2 completo (Jean Carlos).
#   1) Arranca el emulador   2) Estado vulnerable
#   3) Remediación           4) Verificación
# ---------------------------------------------------------------------------
set -euo pipefail
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

bash "${DIR}/01_start_emulator.sh"
bash "${DIR}/02_usuario_permisos_excesivos.sh"
bash "${DIR}/03_remediacion_minimo_privilegio.sh"
echo
echo "Laboratorio 2 finalizado. Revisa lab2-iam-policies/evidence/"
