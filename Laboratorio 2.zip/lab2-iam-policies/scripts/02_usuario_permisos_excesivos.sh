#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# 02 - ANTES (vulnerable): crea el usuario de desarrollo y le asigna la
#      política administrada AdministratorAccess (Action:* / Resource:*).
#      Esto viola el principio de mínimo privilegio.
# ---------------------------------------------------------------------------
source "$(dirname "${BASH_SOURCE[0]}")/lib.sh"

OUT="${EVIDENCE_DIR}/01_antes_permisos_excesivos.txt"
exec > >(tee "${OUT}") 2>&1

log "1. Crear usuario de prueba: ${USER_NAME}"
aws iam create-user --user-name "${USER_NAME}" \
  --tags Key=rol,Value=desarrollo Key=entorno,Value=lab || true

log "2. Asignar política INSEGURA con permisos totales (AdministratorAccess)"
aws iam attach-user-policy \
  --user-name "${USER_NAME}" \
  --policy-arn "${ADMIN_POLICY_ARN}"

log "3. Políticas administradas actualmente asociadas al usuario"
aws iam list-attached-user-policies --user-name "${USER_NAME}"

log "4. Documento real de la política AdministratorAccess (Action:* / Resource:*)"
aws iam get-policy-version \
  --policy-arn "${ADMIN_POLICY_ARN}" \
  --version-id "$(aws iam get-policy --policy-arn "${ADMIN_POLICY_ARN}" --query 'Policy.DefaultVersionId' --output text)" \
  --query 'PolicyVersion.Document'

log "5. Evaluación de acciones de alto riesgo (antes de la remediación)"
"${PYTHON}" "${LAB_DIR}/scripts/audit_permissions.py" \
  --endpoint-url "${ENDPOINT_URL}" --user "${USER_NAME}"

warn "ESTADO: el usuario posee control TOTAL de la cuenta (riesgo crítico de escalado de privilegios)."
ok "Evidencia guardada en ${OUT}"
