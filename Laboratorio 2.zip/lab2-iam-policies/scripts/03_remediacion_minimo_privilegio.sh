#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# 03 - DESPUÉS (remediación): desvincula AdministratorAccess y aplica una
#      política de MÍNIMO PRIVILEGIO (solo lectura del bucket sensible).
# ---------------------------------------------------------------------------
source "$(dirname "${BASH_SOURCE[0]}")/lib.sh"

OUT="${EVIDENCE_DIR}/02_despues_minimo_privilegio.txt"
exec > >(tee "${OUT}") 2>&1

log "1. Desvincular la política de administrador (AdministratorAccess)"
aws iam detach-user-policy \
  --user-name "${USER_NAME}" \
  --policy-arn "${ADMIN_POLICY_ARN}"

log "2. Crear política de MÍNIMO PRIVILEGIO (lectura solo del bucket ${BUCKET})"
aws iam create-policy \
  --policy-name "${CUSTOM_POLICY_NAME}" \
  --description "Mínimo privilegio: solo lectura del bucket empresa-datos-sensibles" \
  --policy-document "file://${LAB_DIR}/policies/minimo-privilegio-s3.json" \
  --tags Key=rol,Value=desarrollo Key=entorno,Value=lab || true

log "3. Asignar la política restringida al usuario"
aws iam attach-user-policy \
  --user-name "${USER_NAME}" \
  --policy-arn "${CUSTOM_POLICY_ARN}"

log "4. Políticas administradas asociadas tras la remediación"
aws iam list-attached-user-policies --user-name "${USER_NAME}"

log "5. Documento de la política aplicada (acciones permitidas)"
aws iam get-policy-version \
  --policy-arn "${CUSTOM_POLICY_ARN}" \
  --version-id "$(aws iam get-policy --policy-arn "${CUSTOM_POLICY_ARN}" --query 'Policy.DefaultVersionId' --output text)" \
  --query 'PolicyVersion.Document'

log "6. Evaluación de acciones de alto riesgo (después de la remediación)"
"${PYTHON}" "${LAB_DIR}/scripts/audit_permissions.py" \
  --endpoint-url "${ENDPOINT_URL}" --user "${USER_NAME}"

ok "Remediación aplicada. Evidencia guardada en ${OUT}"
