# Laboratorio 2 — Políticas IAM e Inseguridad de Permisos

**Integrante:** Jean Carlos Gonzalez Aragon
**Rol:** Especialista en Identidad y Políticas IAM
**Directorio GitHub:** `/lab2-iam-policies/`
**Tema:** Permisos excesivos (AdministratorAccess) vs. principio de **Mínimo Privilegio**

---

## 1. Objetivo

Demostrar, en un entorno controlado, cómo una política IAM con permisos totales
(`Action: * / Resource: *`) otorga a un usuario de desarrollo el control completo
de la cuenta cloud, y cómo aplicar el **principio de menor privilegio** reduce la
superficie de ataque sin romper la funcionalidad requerida (lectura de un bucket
específico).

## 2. Entorno del laboratorio

| Componente | Uso en este lab |
|---|---|
| Emulador de AWS | **moto** (`moto_server`) en `http://localhost:4566` — reemplaza a LocalStack porque el equipo no dispone de Docker en esta máquina. La API es idéntica, por lo que los comandos del documento funcionan igual. |
| AWS CLI | Gestión de usuarios y políticas IAM. |
| Python/boto3 | Auditor que evalúa las acciones de alto riesgo (evidencia "antes vs después"). |

> El endpoint `http://localhost:4566` es el mismo que usa LocalStack en la guía
> original, así que los comandos son portables entre ambos emuladores.

## 3. Estructura de archivos

```
lab2-iam-policies/
├── README.md
├── policies/
│   ├── administrator-access-riesgo.json     # Ejemplo de política con Action:*
│   └── minimo-privilegio-s3.json            # Política de mínimo privilegio (bucket específico)
├── scripts/
│   ├── lib.sh                               # Configuración común
│   ├── 01_start_emulator.sh                 # Levanta el emulador (moto)
│   ├── 02_usuario_permisos_excesivos.sh     # ANTES: usuario + AdministratorAccess
│   ├── 03_remediacion_minimo_privilegio.sh  # DESPUÉS: detach admin + política restringida
│   ├── audit_permissions.py                 # Evaluador de acciones de alto riesgo
│   ├── 99_cleanup.sh                        # Limpieza del entorno
│   └── run_all.sh                           # Ejecuta todo el laboratorio
└── evidence/
    ├── 01_antes_permisos_excesivos.txt      # Salida capturada (estado vulnerable)
    └── 02_despues_minimo_privilegio.txt     # Salida capturada (estado remediado)
```

## 4. Despliegue paso a paso

```bash
# 0. (Solo la primera vez) crear entorno virtual e instalar dependencias sin sudo
cd /home/kali/Laboratorio
python3 -m venv .venv
./.venv/bin/pip install awscli "moto[server]" boto3

# 1. Ejecutar el laboratorio completo
./lab2-iam-policies/scripts/run_all.sh

# Alternativa: paso a paso
./lab2-iam-policies/scripts/01_start_emulator.sh
./lab2-iam-policies/scripts/02_usuario_permisos_excesivos.sh
./lab2-iam-policies/scripts/03_remediacion_minimo_privilegio.sh

# Limpieza final
./lab2-iam-policies/scripts/99_cleanup.sh
```

### Comandos equivalentes (tal como aparecen en el documento)

```bash
# ANTES — crear usuario y darle control total
aws --endpoint-url=http://localhost:4566 iam create-user --user-name usuario-desarrollo
aws --endpoint-url=http://localhost:4566 iam attach-user-policy \
    --user-name usuario-desarrollo --policy-arn arn:aws:iam::aws:policy/AdministratorAccess

# DESPUÉS — quitar el permiso total y aplicar mínimo privilegio
aws --endpoint-url=http://localhost:4566 iam detach-user-policy \
    --user-name usuario-desarrollo --policy-arn arn:aws:iam::aws:policy/AdministratorAccess
aws --endpoint-url=http://localhost:4566 iam create-policy \
    --policy-name MinimoPrivilegio-S3-Lectura \
    --policy-document file://lab2-iam-policies/policies/minimo-privilegio-s3.json
aws --endpoint-url=http://localhost:4566 iam attach-user-policy \
    --user-name usuario-desarrollo \
    --policy-arn arn:aws:iam::123456789012:policy/MinimoPrivilegio-S3-Lectura
```

## 5. Resultados obtenidos

Evaluación de acciones de alto riesgo sobre el usuario `usuario-desarrollo`:

| Acción solicitada | ANTES (AdministratorAccess) | DESPUÉS (Mínimo Privilegio) |
|---|---|---|
| `iam:CreateUser` (persistencia) | PERMITIDO | **DENEGADO** |
| `iam:CreateAccessKey` | PERMITIDO | **DENEGADO** |
| `iam:AttachUserPolicy` (auto-escalado) | PERMITIDO | **DENEGADO** |
| `s3:GetObject` bucket autorizado | PERMITIDO | PERMITIDO |
| `s3:GetObject` bucket NO autorizado | PERMITIDO | **DENEGADO** |
| `s3:DeleteBucket` | PERMITIDO | **DENEGADO** |
| `ec2:TerminateInstances` | PERMITIDO | **DENEGADO** |
| **Total denegadas** | **0/7** | **6/7** |

La única acción que permanece permitida es la lectura del bucket `empresa-datos-sensibles`,
que es exactamente la funcionalidad legítima del usuario de desarrollo.

## 6. Análisis de riesgo

| Vector de riesgo | Impacto potencial | Mitigación aplicada |
|---|---|---|
| Permisos IAM excesivos (`Action:*`) | Escalado de privilegios y toma de control total de la cuenta. | Política de mínimo privilegio acotada por recurso (`arn:aws:s3:::empresa-datos-sensibles/*`). |
| Cuenta de desarrollo con permisos de administrador | Persistencia del atacante (crear usuarios/claves). | Denegación de acciones IAM no necesarias. |
| Acceso a datos fuera del alcance | Exfiltración de otros buckets. | `Resource` limitado a un único bucket. |

## 7. Conclusiones

- Asignar `AdministratorAccess` a cuentas operativas es un error crítico: cualquier
  compromiso de credenciales equivale a **comprometer toda la cuenta**.
- El principio de **mínimo privilegio** permite conservar la función (leer el bucket
  necesario) eliminando 6 de 7 acciones de alto riesgo evaluadas.
- La evidencia se genera de forma **reproducible** (`evidence/`), cumpliendo con la
  trazabilidad solicitada para el entregable de Jean Carlos.
