Las evidencias (salidas de comandos) se guardan aqui automaticamente.
